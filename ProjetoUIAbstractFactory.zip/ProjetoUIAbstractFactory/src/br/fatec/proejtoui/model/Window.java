/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package br.fatec.proejtoui.model;

/**
 *
 * @author Aluno
 */
public interface Window {
      String render();
}
