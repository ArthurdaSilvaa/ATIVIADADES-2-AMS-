/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.fatec.proejtoui.model;

/**
 *
 * @author Aluno
 */
public class DarkWindow implements Window{
    
      public String render(){
          
          return "Janela com tema escuro";
      }
    
}
