/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.fatec.proejtoui.model;

/**
 *
 * @author Aluno
 */
public class LightButton implements Button {
    
    @Override
    public String render(){
        
        return "Botao com tema claro";
    }
    
}
