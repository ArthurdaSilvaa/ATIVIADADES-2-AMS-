/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package br.fatec.projetoui.abstractfactory;

import br.fatec.proejtoui.model.Button;
import br.fatec.proejtoui.model.Window;

/**
 *
 * @author Aluno
 */
public interface UIFactory {
        
    Button createButton();
    
    Window createWindow();

    
}
