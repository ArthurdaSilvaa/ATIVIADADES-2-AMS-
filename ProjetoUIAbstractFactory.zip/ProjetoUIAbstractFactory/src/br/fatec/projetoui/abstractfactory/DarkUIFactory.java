/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.fatec.projetoui.abstractfactory;

import br.fatec.proejtoui.model.Button;
import br.fatec.proejtoui.model.DarkButton;
import br.fatec.proejtoui.model.DarkWindow;
import br.fatec.proejtoui.model.Window;

/**
 *
 * @author Aluno
 */
public class DarkUIFactory  implements UIFactory{
    
 
    @Override
    public Button createButton() {
      return new DarkButton();    }

    @Override
    public Window createWindow() {
       return  new DarkWindow();    }

    
    
    
}
