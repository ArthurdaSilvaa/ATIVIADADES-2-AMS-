/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.fatec.projetoui.abstractfactory;

import br.fatec.proejtoui.model.Button;
import br.fatec.proejtoui.model.LightButton;
import br.fatec.proejtoui.model.LightWindow;
import br.fatec.proejtoui.model.Window;


public class LightUIFactory  implements UIFactory{

    @Override
    public Button createButton() {
        
       return new LightButton();
    }

    /**
     *
     * @return
     */
    @Override
    public Window createWindow() {
        
        return new LightWindow();
    }
    
    
    
}
