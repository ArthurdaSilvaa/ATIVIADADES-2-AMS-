/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.fatec.projetoui.aplicacao;

import br.fatec.projetoui.abstractfactory.DarkUIFactory;
import br.fatec.projetoui.abstractfactory.LightUIFactory;
import br.fatec.projetoui.abstractfactory.UIFactory;
import br.fatec.projetoui.cliente.Cliente;

/**
 *
 * @author Aluno
 */
public class Aplicacao {
      public static void main(String[] args) {
        
          String theme = "dark"; //TOque para "light" para outro tema
          
          UIFactory factory;
          
          if (theme.equals("light")){
              factory = new LightUIFactory();
              Cliente.renderUI(factory);
          } else if (theme.equals("dark")){
              factory = new DarkUIFactory();
              Cliente.renderUI(factory);
              
          }
                  
                  
    }
}
