/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package heranca;

/**
 *
 * @author Aluno
 */
public class Lobo  extends Canino{
    
        
           public void comer (int p) {
               System.out.print("Lobo comeu");          
                       
                       
              }

}
