/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package heranca;


public class Heranca {

   
    public static void main(String[] args) {
     
          Lobo l = new Lobo ();
          l.comer();
    }
    
}
