/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package VeiCarMoto;

import VeiCarMoto.Veiculo;

/**
 *
 * @author Aluno
 */
public class Carro extends Veiculo{
    
    private Veiculo cor;
    private Veiculo chassi;
    private Veiculo placa;

   
    @Override
    public void EmitirGuiaSeguro(){
        
     System.out.println("\nO Carro emitiu a guia do Seguro \n");
             
    }
}
