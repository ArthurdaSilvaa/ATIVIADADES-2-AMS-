/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package VeiCarMoto;

/**
 *
 * @author Aluno
 */
public class PrincipalVeiculo {
       
    public static void main(String[] args) {
        
         Carro c = new Carro();
         c.EmitirGuiaSeguro();
         
         Moto m = new Moto();
         
         m.EmitirGuiaSeguro();
         
    }
}
