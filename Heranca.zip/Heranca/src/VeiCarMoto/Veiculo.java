/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package VeiCarMoto;

/**
 *
 * @author Aluno
 */
public class Veiculo {
         private String cor;
         private String chassi;
         private String placa;

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public String getChassi() {
        return chassi;
    }

    public void setChassi(String chassi) {
        this.chassi = chassi;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }
         
           public void EmitirGuiaSeguro(){
               
               System.out.println("O Veiculo esta emitindo a guia do seguro ");
           }
}
