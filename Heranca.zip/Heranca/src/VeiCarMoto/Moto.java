/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package VeiCarMoto;

import VeiCarMoto.Veiculo;

/**
 *
 * @author Aluno
 */
public class Moto {
          private Veiculo cor;
    private Veiculo chassi;
    private Veiculo placa;

    

    public void EmitirGuiaSeguro(){
        
     System.out.println("\n A Moto emitiu a guia do Seguro \n");
             
    }
}
