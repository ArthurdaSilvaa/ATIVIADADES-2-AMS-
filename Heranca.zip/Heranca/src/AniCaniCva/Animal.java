/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AniCaniCva;

/**
 *
 * @author Aluno
 */
public class Animal {
           protected float tamanho;
           protected String cor;

    public float getTamanho() {
        return tamanho;
    }

    public void setTamanho(float tamanho) {
        this.tamanho = tamanho;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
  
}
           
           public void comer(){
                System.out.print("O Animal esta Comendo");
           }
}
