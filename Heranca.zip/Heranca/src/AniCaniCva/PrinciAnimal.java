/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AniCaniCva;

import AniCaniCva.Cavalo;

/**
 *
 * @author Aluno
 */
public class PrinciAnimal {
        
    public static void main(String[] args) {
        
           Leao l = new Leao();
           l.comer();
           l.cacar();
           
           Cavalo c = new Cavalo();
           
           c.fugir();
           c.comer();
    }
}
