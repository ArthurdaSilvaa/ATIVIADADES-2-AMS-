/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula26.pkg02;

/**
 *
 * @author Aluno
 */
public class Principal {
           public static void main(String[] args) {
              
               
              Curso c = new Curso ("Dsenvolvimento de Sistemas", "Tarde");
              Disciplina d = new Disciplina("Modelagens de Padroes de Projetos", 160);
              Aluno a = new Aluno ("Arthur", c, d);   
            
              System.out.println(a);
    }
}
