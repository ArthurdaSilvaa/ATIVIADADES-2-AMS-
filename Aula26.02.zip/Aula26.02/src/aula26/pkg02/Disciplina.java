/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula26.pkg02;

/**
 *
 * @author Aluno
 */
public class Disciplina {
           private String disciplina;
           private int cargahoraria;
           
           public Disciplina( String disciplina, int cargahoraria){
               this.disciplina = disciplina;
               this.cargahoraria = cargahoraria;
               
               
               
           }

    public String getDisciplina() {
        return disciplina;
    }

    public void setDisciplina(String disciplina) {
        this.disciplina = disciplina;
    }

    public int getCargahoraria() {
        return cargahoraria;
    }

    public void setCargahoraria(int cargahoraria) {
        this.cargahoraria = cargahoraria;
    }
    
    public String toString(){
        return  this.disciplina +
                "\nCarga Horaria: " + this.cargahoraria;
    }
}
