/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package aula26.pkg02;

/**
 *
 * @author Aluno
 */
public class AtividadeRevisao {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
         Endereco e = new Endereco("Diego de Oliveria Rapa ", "Ourinhos", "19915-001", "Flanboyant", 64);
         
         Pessoa p = new Pessoa ("Arthur", 19, e);
           System.out.println(p);
}
           
    }
   
