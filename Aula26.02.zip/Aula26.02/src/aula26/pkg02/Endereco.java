/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula26.pkg02;

/**
 *
 * @author Aluno
 */
public class Endereco {
    
            private String rua;
            private String cidade;
            private String cep;
            private String bairro;
            private int num;

    public Endereco(String rua, String cidade, String cep, String Bairro, int num) {
        this.rua = rua;
        this.cidade = cidade;
        this.cep = cep;
        this.num = num;
        this.bairro = bairro;
    
    }      
                
               
        public String getRua() {
        return rua;
    }

    public void setRua(String rua) {
        this.rua = rua;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getCep() {
        return cep;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

         public String toString(){
             return "\nRua: " + this.rua +
                     "\nNumero: " + this.num + 
                     "\nBairro: " + this.bairro +
                     "\nCidade: " + this.cidade + 
                     "\nCEP" + this.cep;
         }     
            
            
}
