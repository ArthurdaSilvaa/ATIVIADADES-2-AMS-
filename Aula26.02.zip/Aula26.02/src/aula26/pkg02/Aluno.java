/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula26.pkg02;

/**
 *
 * @author Aluno
 */
public class Aluno {
            private String nome;
            private Curso curso;
            private Disciplina disciplina;
    public Aluno(String nome, Curso curso, Disciplina disciplina) {
        this.nome = nome;
        this.curso = curso;
        this.disciplina = disciplina;
        
        
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Curso getCurso() {
        return curso;
    }

    public void setCurso(Curso curso) {
        this.curso = curso;
    }

    public Disciplina getDisciplina() {
        return disciplina;
    }

    public void setDisciplina(Disciplina disciplina) {
        this.disciplina = disciplina;
    }
            public String toString(){
                return "\nNome:" + this.nome + 
                        "\nCurso: " + this.curso + 
                        "\nDisciplina: " + this.disciplina;
                
            }
            
            
}
