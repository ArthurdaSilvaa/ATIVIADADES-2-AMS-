/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AtividadeAdapter;

/**
 *
 * @author aluno
 */
public class Main {
     
     public static void main(String[] args) {

        ServicoPagamentoLegado servicoLegado =
                new ServicoPagamentoLegado();

        AdaptadorPagamento adaptador =
                new AdaptadorPagamento(servicoLegado);

        SistemaCompras sistemaCompras =
                new SistemaCompras(adaptador);

        sistemaCompras.finalizarCompra(250.00);
    }
}
