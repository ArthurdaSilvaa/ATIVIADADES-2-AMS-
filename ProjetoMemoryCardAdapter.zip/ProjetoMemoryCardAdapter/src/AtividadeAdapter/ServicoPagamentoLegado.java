/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AtividadeAdapter;

/**
 *
 * @author aluno
 */
public class ServicoPagamentoLegado {
     
     public void efetuarPagamento(double valorEmReais) {
        System.out.printf(
            "Pagamento legado realizado no valor de R$ %.2f%n",
            valorEmReais
        );
    }
}
