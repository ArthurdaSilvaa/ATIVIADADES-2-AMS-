/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AtividadeAdapter;

/**
 *
 * @author aluno
 */
public class AdaptadorPagamento implements Pagamento {
      

    

    private ServicoPagamentoLegado servicoLegado;

    public AdaptadorPagamento(ServicoPagamentoLegado servicoLegado) {
        this.servicoLegado = servicoLegado;
    }

    @Override
    public void pagar(double valor) {
        servicoLegado.efetuarPagamento(valor);
    }
}
