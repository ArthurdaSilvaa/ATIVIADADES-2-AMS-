/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AtividadeAdapter;

/**
 *
 * @author aluno
 */



public class SistemaCompras {

    private Pagamento pagamento;

    public SistemaCompras(Pagamento pagamento) {
        this.pagamento = pagamento;
    }

    public final void finalizarCompra(double valor) {
        System.out.println("Finalizando compra...");
        
        pagamento.pagar(valor);
        
        System.out.println("Compra concluída com sucesso.");
    }
}
