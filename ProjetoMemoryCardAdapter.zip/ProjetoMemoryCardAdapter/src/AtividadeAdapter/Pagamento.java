/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package AtividadeAdapter;

/**
 *
 * @author aluno
 */
public interface Pagamento {
          
      void pagar(double valor);
}
