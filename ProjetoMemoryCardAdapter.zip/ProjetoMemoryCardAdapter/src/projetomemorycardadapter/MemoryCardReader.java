/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package projetomemorycardadapter;

/**
 *
 * @author aluno
 */
public class MemoryCardReader {
    
      public void readMemoryCard(MemoryCard card){
          card.readData();
      }
}
