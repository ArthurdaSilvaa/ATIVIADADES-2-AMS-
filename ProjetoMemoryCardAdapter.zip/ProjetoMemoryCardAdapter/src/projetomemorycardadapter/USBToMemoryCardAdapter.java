/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package projetomemorycardadapter;

/**
 *
 * @author aluno
 */
public class USBToMemoryCardAdapter implements MemoryCard {
       
    
    private USBDrive usbDrive;
    
    public USBToMemoryCardAdapter(USBDrive usbDrive){
            this.usbDrive = usbDrive;
    }

    @Override
    public void readData() {
           System.out.println("Adptadro em acao: convertendo USB para MemoryCard...");
           usbDrive.readFromUSB();
    }
}
