/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package projetomemorycardadapter;

/**
 *
 * @author aluno
 */
public class USBDrive {
       
    public void readFromUSB (){
        System.out.println("Lendo dados do pen drive via USB...");
    }
}
