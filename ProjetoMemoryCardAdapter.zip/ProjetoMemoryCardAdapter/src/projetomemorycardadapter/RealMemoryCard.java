/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package projetomemorycardadapter;

/**
 *
 * @author aluno
 */
public class RealMemoryCard implements MemoryCard {
    
       @Override
       public void readData(){
           System.out.println("Lendo dados diretamentes do cartao de memoria...");
       }
}
