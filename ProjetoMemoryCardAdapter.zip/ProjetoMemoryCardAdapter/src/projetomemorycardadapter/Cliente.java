/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package projetomemorycardadapter;

/**
 *
 * @author aluno
 */
public class Cliente {
      public static void main(String[] args) {
          
        MemoryCardReader reader = new MemoryCardReader();
        
        MemoryCard realCard = new RealMemoryCard();
        System.out.println("=== Leitura do MemoryCard real ===");
        reader.readMemoryCard(realCard);
        
        System.out.println();
        
        USBDrive usbDrive = new USBDrive();
        MemoryCard adaptedUSB = new USBToMemoryCardAdapter(usbDrive);
        System.out.println("=== Leitura de um USBDrive com Adapter");
        reader.readMemoryCard(adaptedUSB);
    }
}
