/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula19.pkg02;

/**
 *
 * @author Aluno
 */
public class Pessoa {
      private String nome;
      private int idade;

     

      public Pessoa(String nome , int idade){

this.nome = nome;
this.idade = idade;
}


    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }
   
    
    
    public void exibirpessoa(){
        System.out.println("Ola, meu nome e" + this.nome + 
                "\n" + " e tenho" + this.idade + "anos");
    }
       

    
}