/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula19.pkg02;

/**
 *
 * @author Aluno
 */
public class PrinciProduto {
       
    public static void main(String[] args) {
        
        
        Produto pro = new Produto("Lapis" , 1.90 , 100  );
    
     
     pro.exibir();
          
          
      }
      
    
}


  
