/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula19.pkg02;

/**
 *
 * @author Aluno
 */
public class Aluno {
       
    private String nome;
    private double nota1;
    private double nota2;
    
    
    
    public Aluno (String nome , double nota1, double nota2){
        
        this.nome = nome;
        this.nota1 = nota1;
        this.nota2 = nota2;
      
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getNota1() {
        return nota1;
    }

    public void setNota1(double nota1) {
        this.nota1 = nota1;
    }

    public double getNota2() {
        return nota2;
    }

    public void setNota2(double nota2) {
        this.nota2 = nota2;
    }
    
   public double calcumedia(){
       return (nota1 + nota2 ) / 2; 
   }
   
   public String verificarAprovacao(){
       if (calcumedia() >= 6.0){
           return "APROVADO";
       }  else {
           return "REPROVADO";
       }
   }
   
   public void exibir(){
       System.out.println ("Nome:" + this.nome +
               "\n" + "1 NOTA:" + this.nota1 +
               "\n" + "2 NOTA" + this.nota2 +
              "\n" +   this.verificarAprovacao());
   }
}




