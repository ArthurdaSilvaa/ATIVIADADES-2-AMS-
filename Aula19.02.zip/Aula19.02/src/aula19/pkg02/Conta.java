/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula19.pkg02;

/**
 *
 * @author Aluno
 */

public class Conta{
   public static void main(String[] args) {
     
       ContaBancaria conta = new ContaBancaria("Arthur", 1000.0);
    
       conta.exibirSaldo();
       
       conta.depositar(500.0);
       System.out.println("Depósito realizado.");
       conta.exibirSaldo();
     
       boolean saque = conta.sacar(300.0);
       if (saque) {
           System.out.println("Saque realizado com sucesso.");
       } else {
           System.out.println("Saldo insuficiente.");
       }
    
       conta.exibirSaldo();
   }
}
