/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula19.pkg02;

/**
 *
 * @author Aluno
 */
public class PrinciAluno {
      public static void main(String[] args) {
        
         Aluno a= new Aluno("Arthur", 10, 9);
          
      a.exibir();
    }
      
  
}
