/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula19.pkg02;

/**
 *
 * @author Aluno
 */
public class ContaBancaria {

  

    private String titular;

    private double saldo;

    
    public ContaBancaria(String titular, double saldoInicial) {

        this.titular = titular;

        this.saldo = saldoInicial;

    }

  

    public String getTitular() {

        return titular;

    }

    public double getSaldo() {

        return saldo;

    }

    // Métodos Setters

    public void setTitular(String titular) {

        this.titular = titular;

    }

    public void setSaldo(double saldo) {

        this.saldo = saldo;

    }

    // Método para depositar

    public void depositar(double valor) {

        if (valor > 0) {

            saldo += valor;

        }

    }

    // Método para sacar

    public boolean sacar(double valor) {

        if (valor > 0 && saldo >= valor) {

            saldo -= valor;

            return true;

        } else {

            return false;

        }

    }

    // Método para exibir saldo

    public void exibirSaldo() {

        System.out.println("Saldo atual: R$ " + saldo);

    }

}
 