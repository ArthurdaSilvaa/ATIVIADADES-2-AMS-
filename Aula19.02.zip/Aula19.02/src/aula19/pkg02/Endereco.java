/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula19.pkg02;

/**
 *
 * @author Aluno
 */
public class Endereco {
   private String rua;
   private int numero;
   private String cidade;
   private String cep;
   private String bairro;
 
   
   public Endereco(String rua, int numero, String cidade, String cep, String bairro) {
       this.rua = rua;
       this.numero = numero;
       this.cidade = cidade;
       this.cep = cep;
       this.bairro = bairro;
   }
   // Getters
   public String getRua() {
       return rua;
   }
   public int getNumero() {
       return numero;
   }
   public String getCidade() {
       return cidade;
   }
   public String getCep() {
       return cep;
   }
   public String getBairro() {
       return bairro;
   }
   // Setters
   public void setRua(String rua) {
       this.rua = rua;
   }
   public void setNumero(int numero) {
       this.numero = numero;
   }
   public void setCidade(String cidade) {
       this.cidade = cidade;
   }
   public void setCep(String cep) {
       this.cep = cep;
   }
   public void setBairro(String bairro) {
       this.bairro = bairro;
   }
   
   
   public void exibirr(){    
   System.out.println("Rua: " + this.rua + "\n" +
           "Numero:" + this.numero + "\n" +
           "Cidade:" + this.cidade + "\n" + 
           "CEP:" + this.cep + "\n" + 
           "Bairo:" + this.bairro);
      
   }
}