/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula19.pkg02;

/**
 *
 * @author Aluno
 */
public class Produto {
    
      private String nome;
       private double preco;
       private int quantidade;
   
      
       
       public Produto( String nome, double preco, int quantidade){
          
           
           this.nome = nome;
           this.preco = preco;
           this.quantidade = quantidade;
       }
          
       
       public String getnome(){
           return nome;
       }
       
      public void setNome( String nome){
          this.nome = nome;
      }
      
      public double getpreco(){
          return preco;
      }
      
      public void setpreco( double preco){
          this.preco = preco;
      }
      
      public int getquantidade(){
          return quantidade;
      }
      
      public void setquantidade( int quantidade ){
          this.quantidade = quantidade;
      }
      
      public double calculartotal(){
          
         return this.preco * this.quantidade;
        
      }
      
      public void exibir(){
          
          System.out.println( "Nome:" + this.nome +
                  "\n" + "Preço:" + this.preco +
                    "\n" + "Quantidade:" + this.quantidade +
                    "\n" + "soma:" + this.calculartotal());
      }
}
