   /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula19.pkg02;

/**
 *
 * @author Aluno
 */
public class PrinciRetangulo {
    
 
   public static void main(String[] args) {
       
       Retangulo ret = new Retangulo(5.0, 3.0);
       
      ret.exibirret();
   }
}   

