/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula19.pkg02;

/**
 *
 * @author Aluno
 */
public class Retangulo {
   // Atributos privados
   private double largura;
   private double altura;
   // Construtor
   public Retangulo(double largura, double altura) {
       this.largura = largura;
       this.altura = altura;
   }
   // Getters
   public double getLargura() {
       return largura;
   }
   public double getAltura() {
       return altura;
   }
   // Setters
   public void setLargura(double largura) {
       this.largura = largura;
   }
   public void setAltura(double altura) {
       this.altura = altura;
   }
   // Método para calcular área
   public double calcularArea() {
       return largura * altura;
   }
   // Método para calcular perímetro
   public double calcularPerimetro() {
       return 2 * (largura + altura);
   }
   
   public void exibirret(){
       System.out.println("Larugra:" + this.largura + "\n" +
                "Altura:" + this.altura +  "\n" + 
               "Area:" + this.calcularArea() + "\n" + 
               "Perimetro:" + this.calcularPerimetro());
   }
}