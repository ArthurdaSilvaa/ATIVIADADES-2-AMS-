/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package aula19.pkg02;

/**
 *
 * @author Aluno
 */
public class AtividadeRevisao {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
             Carro c = new Carro( "Fiat", "Flex", 2000);
             
             c.setMarca("GOLF SPORTLINE");
             
             c.exibirinfo();
    }
    
}
