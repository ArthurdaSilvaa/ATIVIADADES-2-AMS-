/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula19.pkg02;

/**
 *
 * @author Aluno
 */
public class PrinciEndereco{
   public static void main(String[] args) {
       // Criando o endereço
       Endereco end = new Endereco(
               "Rua das Flores",
               123,
               "São Paulo",
               "01000-000",
               "Centro"
       );
       
    end.exibirr();
   }
}
