/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.fatec.Veiculofactorysimples.model;

/**
 *
 * @author Aluno
 */
public class Carro implements Veiculo{
    
    
    @Override
    public void exibirDetalhes(){
        System.out.println("Carro criado");
    }
}
