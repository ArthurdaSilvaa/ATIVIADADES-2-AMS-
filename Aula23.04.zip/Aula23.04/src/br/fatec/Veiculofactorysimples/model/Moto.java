/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.fatec.Veiculofactorysimples.model;

/**
 *
 * @author Aluno
 */
public  class Moto implements Veiculo {
    
    public void exibirDados(){
        System.out.println("Moto criada");
    }

  
 
}
