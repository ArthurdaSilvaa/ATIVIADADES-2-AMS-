/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projetosintonthreadsafe;

public class Cliente {
         
           public static void main(String[] args) {
          
               
               
               Runnable tarefa = () -> {
                   Logger logger = Logger.getInstance();
                   logger.log("Mensagem de log.");
                   
               };
               
               Thread thread1 = new Thread(tarefa, "Thread-1");
               Thread thread2 = new Thread(tarefa, "Thread-2");
               Thread thread3 = new Thread(tarefa, "Thread-13");
              
               
               thread1.start();
               thread2.start();
               thread3.start();
                       }       
  
}
