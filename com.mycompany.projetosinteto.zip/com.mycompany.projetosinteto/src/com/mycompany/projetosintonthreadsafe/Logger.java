/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projetosintonthreadsafe;


public class Logger  {
      
    private static Logger instance;  
    
    private Logger(){
          System.out.println("Logger iniciado");
      }
    
      public static synchronized Logger getInstance(){
         if (instance == null){
             instance = new Logger();
         } 
         return instance;
         }
      
      public void log(String mensagem) {
          System.out.println(Thread.currentThread().getName() + "- LOG: " + mensagem);
      }
}
