/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projetosingletoneager;

/**
 *
 * @author Aluno
 */
public class DatabaseConnection {
       
    private static final DatabaseConnection instance = 
           new DatabaseConnection();
    
    private DatabaseConnection(){
         System.out.println("Conectando ao banco de daods!");   
    }
    public static DatabaseConnection getInstance(){
        return instance;
    }
    
    public void executarConsulta(String sql){
        System.out.println("Executando consulta:" + sql);
    }
}
