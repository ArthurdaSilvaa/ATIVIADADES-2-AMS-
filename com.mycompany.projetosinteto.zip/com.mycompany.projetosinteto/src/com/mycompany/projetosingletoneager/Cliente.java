/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projetosingletoneager;

/**
 *
 * @author Aluno
 */
public class Cliente {
      public static void main(String[] args) {
         DatabaseConnection conexao = DatabaseConnection.getInstance();
         
         conexao.executarConsulta("SELECT * FROM usuarios");
         
         DatabaseConnection outraConexao = DatabaseConnection.getInstance();
         outraConexao.executarConsulta("UPDATE usuarios SET ativo = 1");
         
         System.out.println("Mesma instancia?" + (conexao == outraConexao));
    }
}
