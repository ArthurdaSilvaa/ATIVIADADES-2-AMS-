/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projetossingletongamesettings;

/**
 *
 * @author Aluno
 */
public class GamesSettings {
    
       private static final GamesSettings instance = new GamesSettings();
       
       private int volume = 50;
       private String dificuldade = "Normal";
       private boolean  fullscreen = true;
       private String idioma = "pt-BR";
       private int resolucaoX = 1920;
       private int resolucaoY = 1080;
       
       private GamesSettings(){
           System.out.println("Configuracoes iniciais caregadas");
       }
       
       public static GamesSettings getInstance(){
           return instance;
       }

    public int getVolume() {
        return volume;
    }

    public void setVolume(int volume) {
        this.volume = volume;
    }

    public String getDificultade() {
        return dificuldade;
    }

    public void setDificuldade(String dificultade) {
        this.dificuldade = dificultade;
    }

    public boolean isFullscreen() {
        return fullscreen;
    }

    public void setFullscreen(boolean fullscreen) {
        this.fullscreen = fullscreen;
    }

    public String getIdioma() {
        return idioma;
    }

    public void setIdioma(String idioma) {
        this.idioma = idioma;
    }

    public int getResolucaoX() {
        return resolucaoX;
    }

    public int getResolucaoY() {
        return resolucaoY;
    }

    public void setResolucao(int x, int y) {
        this.resolucaoY = x;
        this.resolucaoY = y;
    }
       
    public void exibirConfiguracoes(){
        
        System.out.println("=== Configuracoes do Jogo ===");
        System.out.println("Volume: " + volume);
        System.out.println("Dificuldade: " + dificuldade);
        System.out.println("Tela Cheia: " + fullscreen);
        System.out.println("Idioma:" + idioma);
        System.out.println("Resolucao:" + resolucaoX + "x" + resolucaoY);
        
    }     
}
