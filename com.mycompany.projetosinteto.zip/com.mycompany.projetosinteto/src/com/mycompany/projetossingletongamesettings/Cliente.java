/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projetossingletongamesettings;

/**
 *
 * @author Aluno
 */
public class Cliente {
     public static void main(String[] args) {
         
        GamesSettings settings = GamesSettings.getInstance();
      System.out.println("\nConfiguracao Padrao Inicial da Unica Instancia Criada:");
        settings.exibirConfiguracoes();
        
        
        settings.setVolume(80);
        settings.setDificuldade("Dificil");
        settings.setIdioma("eu-US");
        settings.setFullscreen(false);
        settings.setResolucao(1290, 700);
        
        
        System.out.println("\nConfiguracoes modificadas em settings: ");
        
        GamesSettings gameplaySettings = GamesSettings.getInstance();
     System.out.println("\nAcessando configuracoes (gameplaySettings) durando o jogo");
        gameplaySettings.exibirConfiguracoes();;
                
                
                
                
           
    }
      
}
