let cadeiras = {};
let usuarios = {};
let usuarioAtual = null;

const mapa = document.getElementById("mapa");
const mensagem = document.getElementById("mensagem");

// 🔐 LOGI  

// 🔐 ENTRAR
function entrar() {
  let email = document.getElementById("email").value;
  let senha = document.getElementById("senha").value;

  let usuarios = JSON.parse(localStorage.getItem("usuarios")) || {};

  if (usuarios[email] && usuarios[email].senha === senha) {
    usuarioAtual = email;

    // 🔥 AQUI ESTÁ A MUDANÇA IMPORTANTE
    let nomeUsuario = usuarios[email].nome;

    document.getElementById("nomeUsuario").innerText = nomeUsuario;

    document.getElementById("login").style.display = "none";
    document.getElementById("sistema").style.display = "block";

    iniciarMapa();
  } else {
    document.getElementById("msgLogin").innerText = "Email ou senha inválidos!";
  }
}

// 📝 CADASTRAR
function cadastrar() {
  let nome = document.getElementById("novoNome").value;
  let email = document.getElementById("novoEmail").value;
  let senha = document.getElementById("novaSenha").value;

  let usuarios = JSON.parse(localStorage.getItem("usuarios")) || {};

  if (!nome || !email || !senha) {
    document.getElementById("msgCadastro").innerText = "Preencha todos os campos!";
    return;
  }

  if (usuarios[email]) {
    document.getElementById("msgCadastro").innerText = "Usuário já existe!";
    return;
  }

  usuarios[email] = {
    nome: nome,
    senha: senha
  };

  localStorage.setItem("usuarios", JSON.stringify(usuarios));

  document.getElementById("msgCadastro").innerText = "Conta criada com sucesso!";
}

// 🔄 TROCAR TELAS
function mostrarCadastro() {
  document.getElementById("login").style.display = "none";
  document.getElementById("cadastro").style.display = "block";
}

function voltarLogin() {
  document.getElementById("cadastro").style.display = "none";
  document.getElementById("login").style.display = "block";
}

// 🚪 LOGOUT
function logout() {
  usuarioAtual = null;

  document.getElementById("sistema").style.display = "none";
  document.getElementById("login").style.display = "block";
}

// 🚪 LOGOUT
function logout() {
  usuarioAtual = null;
  document.getElementById("login").style.display = "block";
  document.getElementById("sistema").style.display = "none";
}

// 🎯 CRIAR MAPA
function iniciarMapa() {
  mapa.innerHTML = "";

  for (let f = 1; f <= 5; f++) {
    for (let c = 1; c <= 5; c++) {
      let pos = `${f}-${c}`;

      if (!(pos in cadeiras)) {
        cadeiras[pos] = null;
      }

      let div = document.createElement("div");
      div.classList.add("cadeira");

      if (cadeiras[pos]) {
        div.classList.add("ocupada");
        div.innerText = "X";
      } else {
        div.innerText = pos;
        div.onclick = () => reservar(pos);
      }

      mapa.appendChild(div);
    }
  }
}

// 💺 RESERVAR
function reservar(pos) {
  if (cadeiras[pos]) {
    mensagem.innerText = "Cadeira ocupada!";
    return;
  }

  // simula erro
  if (Math.random() < 0.3) {
    mensagem.innerText = "Erro no sistema, tente novamente!";
    return;
  }

  cadeiras[pos] = usuarioAtual;

  if (!usuarios[usuarioAtual]) {
    usuarios[usuarioAtual] = [];
  }

  usuarios[usuarioAtual].push(pos);

  iniciarMapa();
  mensagem.innerText = `Reservado: ${pos}`;
}

// 🤖 HEURÍSTICA (BUSCA GULOSA)
const centro = { linha: 3, coluna: 3 };

function calcularCusto(pos) {
  let [f, c] = pos.split("-").map(Number);

  let distancia = Math.abs(f - centro.linha) + Math.abs(c - centro.coluna);

  return distancia;
}

function melhorAssento() {
  let melhor = null;
  let menor = Infinity;

  for (let pos in cadeiras) {
    if (!cadeiras[pos]) {
      let custo = calcularCusto(pos);

      if (custo < menor) {
        menor = custo;
        melhor = pos;
      }
    }
  }

  return melhor;
}

function reservarAutomatico() {
  let pos = melhorAssento();

  if (!pos) {
    mensagem.innerText = "Lotado!";
    return;
  }

  cadeiras[pos] = usuarioAtual;

  if (!usuarios[usuarioAtual]) {
    usuarios[usuarioAtual] = [];
  }

  usuarios[usuarioAtual].push(pos);

  iniciarMapa();
  mensagem.innerText = `Melhor assento: ${pos}`;
}

// 📄 VER INGRESSOS
function verIngressos() {
  let lista = usuarios[usuarioAtual];

  if (!lista || lista.length === 0) {
    mensagem.innerText = "Nenhum ingresso.";
    return;
  }

  mensagem.innerText = "Seus ingressos: " + lista.join(", ");
}

// ❌ CANCELAR
function cancelar() {
  let pos = prompt("Qual cadeira deseja cancelar?");

  if (cadeiras[pos] === usuarioAtual) {
    cadeiras[pos] = null;

    usuarios[usuarioAtual] = usuarios[usuarioAtual].filter(p => p !== pos);

    iniciarMapa();
    mensagem.innerText = "Cancelado!";
  } else {
    mensagem.innerText = "Você não possui essa cadeira!";
  }
}