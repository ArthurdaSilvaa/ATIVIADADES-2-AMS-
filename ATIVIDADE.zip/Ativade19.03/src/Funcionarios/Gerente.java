/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Funcionarios;

/**
 *
 * @author arthu
 */
public class Gerente extends Funcionario{
            
    public Gerente(String nome, double salarioBase){
        super(nome,salarioBase);
    }
    @Override
             public double calcularSalario(){
                return salarioBase * 1.20;
            }
}
