/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Calcu;

/**
 *
 * @author arthu
 */
public class Principal {
      public static void main(String[] args) {
        
           Calcular calc = new Calcular();
          
          Quadrado q = new Quadrado(5);
          Circulo c = new Circulo(3);
          
           calc.mostrarArea(c);
           calc.mostrarArea(q);
          
          Forma f = new Forma();
    }
}
