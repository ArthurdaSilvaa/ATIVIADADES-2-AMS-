/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Biblioteca;

/**
 *
 * @author arthu
 */
public class Principal {
      public static void main(String[] args) {
               
          Midias[] midias = new Midias[4];
          
          midias[0] = new Musica("The Weeknd - Call Out My Name ");
          midias[1] = new Musica("Luan Santana - ASAS ");
          midias[2] = new Video ("2 devs especialistas vs. 1 full-stack: quem faz o melhor jogo?");
          midias[3] = new Video ("Minhas Compras Custo Beneficio no Aniversario do Aliexpress");
          
          for( Midias m : midias) {
              System.out.println("Titulo:" + m.titulo + "\n");
          }
          
    }
}
