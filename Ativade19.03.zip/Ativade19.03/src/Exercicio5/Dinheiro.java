/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Exercicio5;

/**
 *
 * @author Aluno
 */
public class Dinheiro extends Pagamento{
    
     
      public Dinheiro(double valor){
          super(valor);
      }
    
      public double realziarPagamento(){
          return valor;
      }
      
      
    
}
