/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Exercicio5;

/**
 *
 * @author Aluno
 */
public class Pagamento {
         
    protected double valor;
    
    public Pagamento(double valor){
        this.valor=valor;
    }
    
    public void realizarPagamento(){
        
    }
}
