/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Exercicio5;

/**
 *
 * @author Aluno
 */
public class Principal {
    
      public static void main(String[] args) {
        
           Caixa c = new Caixa(400);
           
           Pagamento[] pagamento = new Pagamento[3];
          
           pagamento[0] = new Pix(400);
           pagamento[1] = new Dinheiro(400);
           pagamento[2] = new CartaoCredito(600);
            
            for( Pagamento p : pagamento){
                c.processarPagamento(p);
            }
    }
}
