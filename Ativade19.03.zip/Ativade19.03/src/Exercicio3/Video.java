/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Exercicio3;

/**
 *
 * @author arthu
 */
public class Video extends Midias{
    
    public Video(String titulo){
        super(titulo);
    }
    
    @Override
       public void reproduzir(){
            System.out.println("Video");
       }
       }
    

