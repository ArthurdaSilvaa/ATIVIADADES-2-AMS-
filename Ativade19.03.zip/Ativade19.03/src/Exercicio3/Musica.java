/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Exercicio3;

/**
 *
 * @author arthu
 */
public class Musica extends Midias{
          public Musica (String titulo){
             super(titulo);
          }
          @Override
       public void reproduzir(){
             System.out.println("Musica");
       }
       }

