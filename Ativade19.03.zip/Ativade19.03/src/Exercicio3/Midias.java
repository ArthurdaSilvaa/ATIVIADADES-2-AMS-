/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Exercicio3;

/**
 *
 * @author arthu
 */
public class Midias {
        protected String titulo;
        
        public Midias(String titulo){
            this.titulo=titulo;
        }
        
        public void reproduzir(){
            System.out.println("Midia");
        }
}
