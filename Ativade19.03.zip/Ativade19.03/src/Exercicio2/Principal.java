/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Exercicio2;


public class Principal {
      public static void main(String[] args) {
           
          Funcionario[] funcionario = new Funcionario[4];
          
          funcionario[0] = new Gerente("Arthur",10000);
          funcionario[1] = new Gerente("Neymar",20000);
          funcionario[2] = new Desenvolvedor("Pele",3000);
          funcionario[3] = new Desenvolvedor("Messi",4000);
          
          
          for( Funcionario f: funcionario){
          System.out.println("Nome:" + f.nome + "\n" + "Salario:" + f.calcularSalario());
    }
}
}