/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Exercicio2;

/**
 *
 * @author arthu
 */
public class Funcionario {
            protected String nome;
            protected double salarioBase;
            
            public Funcionario(String nome, double salarioBase){
                this.nome=nome;
                this.salarioBase=salarioBase;
            }
            
            public double calcularSalario(){
                return this.salarioBase;
            }
}
