/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Exercicio4;

public class Transporte {
         
       protected double distancia;
       
       
       public Transporte(double distancia){
           this.distancia=distancia;
       }
       
       public double calcularTempoViagem(){
           return this.distancia;
       }    
}
