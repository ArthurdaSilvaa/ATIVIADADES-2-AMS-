/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Exercicio4;

/**
 *
 * @author Aluno
 */
public class Bicicleta extends Transporte {
       
        
            public Bicicleta(double distancia){
           super(distancia);
    }
    
            @Override
      public double calcularTempoViagem(){
           return distancia / 40;
      }
        @Override
       public String toString(){
           
           return "Bicicleta";
       }
}
