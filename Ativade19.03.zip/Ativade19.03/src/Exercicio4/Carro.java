/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Exercicio4;

/**
 *
 * @author Aluno
 */
public class Carro extends Transporte{
     
            
          
          
           public Carro(double distancia){
           super(distancia);
    }
    
    
    @Override
    public double calcularTempoViagem(){
              return distancia / 100;
       } 
    
      @Override
       public String toString(){
           
           return "Carro";
       }
}
