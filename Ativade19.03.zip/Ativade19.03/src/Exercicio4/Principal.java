/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Exercicio4;

/**
 *
 * @author Aluno
 */
public class Principal {
         public static void main(String[] args) {
        
           Transporte[] transporte = new Transporte[3];
           
           
           transporte[0]= new Carro(200);
           transporte[1] = new Bicicleta(200);
           transporte[2]  = new Onibus(200);
           
              for(Transporte t: transporte){
                  System.out.println(" O tempo de viagem e de:" + t +":" + String.format("%.2f",  t.calcularTempoViagem())+ "Horas");
              }
    }
}
