/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ativade19.pkg03;

/**
 *
 * @author Aluno
 */
public class Cachorro extends Canino{
     
    
     
    @Override
    public void fazerbarulho(){
        System.out.println("O Cachorro fez barulho");
    }
    @Override
    public void comer(String comida){
        System.out.println("O Cachorro comeu" + comida);
    }
}
