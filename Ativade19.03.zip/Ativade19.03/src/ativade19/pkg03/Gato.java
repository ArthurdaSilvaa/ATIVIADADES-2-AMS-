/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ativade19.pkg03;

/**
 *
 * @author Aluno
 */
public class Gato extends Felino{
         
    
     
    @Override
    public void fazerbarulho(){
        System.out.println("O Gato fez barulho");
    }
    @Override
    public void comer(String comida){
        System.out.println("O Gato comeu" + comida);
    }
}
