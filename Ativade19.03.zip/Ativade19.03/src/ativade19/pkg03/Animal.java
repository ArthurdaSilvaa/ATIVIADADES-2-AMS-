/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ativade19.pkg03;

/**
 *
 * @author Aluno
 */
public class Animal {
          private  String imagem;
          private String alimento;
          private int fome;
          private double localização;
          private double limites;

    public String getImagem() {
        return imagem;
    }

    public void setImagem(String imagem) {
        this.imagem = imagem;
    }

    public String getAlimento() {
        return alimento;
    }

    public void setAlimento(String alimento) {
        this.alimento = alimento;
    }

    public int getFome() {
        return fome;
    }

    public void setFome(int fome) {
        this.fome = fome;
    }

    public double getLocalização() {
        return localização;
    }

    public void setLocalização(double localização) {
        this.localização = localização;
    }

    public double getLimites() {
        return limites;
    }

    public void setLimites(double limites) {
        this.limites = limites;
    }
          
          public void fazerbarulho(){
              System.out.println("O Animal fez barulho");
          }
          
          public void comer (String comida) {
              System.out.println("O Animal comer" + comida);
          }
          
          public void dormir(){
              System.out.println("Animal dormiu");
          }
          public void vagar(){
              System.out.println("O Animal esta vagando");
          }
}
