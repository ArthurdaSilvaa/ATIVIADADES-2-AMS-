/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Exercicio1;

/**
 *
 * @author arthu
 */
public class Calcular {
   
         public void mostrarArea(Forma f){
            System.out.println("A Area da forma é: " + String.format("%.2f", f.calcularArea()));
         }
}