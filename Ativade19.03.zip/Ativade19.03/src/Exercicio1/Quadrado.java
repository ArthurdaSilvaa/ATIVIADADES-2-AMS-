/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Exercicio1;

/**
 *
 * @author arthu
 */
public class Quadrado extends Forma{
         private double lado;
         
         public Quadrado(double lado){
             this.lado = lado;
         }
         
         @Override
        public double calcularArea(){
            return lado*lado;
        }
    
}
